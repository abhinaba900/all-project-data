import logo from "./logo.svg";
import "./App.css";
import AllRoute from "./Route/AllRoute";

function App() {
  return (
    <div className="App">
      <AllRoute />
    </div>
  );
}

export default App;
