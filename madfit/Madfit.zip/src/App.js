import AllRoute from './AllRoutes/AllRoute';
import './App.css';

function App() {
  return (
    <div className="App">
      <AllRoute />
    </div>
  );
}

export default App;
