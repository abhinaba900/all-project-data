import React from 'react'

function HeadSection() {
  return (
    <div>
      <div id="top-section-text-in-black-background">
        <h3>Try a month of MADFIT for only $1.00</h3>
      </div>
    </div>
  );
}

export default HeadSection
