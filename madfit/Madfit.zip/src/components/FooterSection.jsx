import React from 'react'

function FooterSection() {
  return (
    <div>
      <div className="footer-section">
        <h2>Copyright © Madfit 2024 | Terms & conditions - Privacy policy</h2>
      </div>
    </div>
  );
}

export default FooterSection
