import "./App.css";
import AllRoute from "./allRoutes/AllRoute";

function App() {
  return (
    <div>
      <AllRoute />
    </div>
  );
}

export default App;
